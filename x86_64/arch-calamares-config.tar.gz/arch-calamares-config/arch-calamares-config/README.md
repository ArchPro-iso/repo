arch calamares config
